import auth from "./modules/auth";
import partners from "./modules/partners";
import slider from "./modules/slider";
import cart from './modules/cart';

auth();
partners();
slider();
cart();