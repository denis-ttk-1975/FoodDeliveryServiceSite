const menu = () => {
  const cardsMenu = document.querySelector('.cards-menu');

  // helpers
  const getStoreValue = name => localStorage.getItem(name);
  const setStoreValue = (name, value) => localStorage.setItem(name, value);

  const changeMenuHeader = restaurant => {
    const {kitchen, price, name, stars} = restaurant;

    const restaurantSectionHeading = document.querySelector('.section-heading');
    restaurantSectionHeading.innerHTML = `
      <h2 class="section-title restaurant-title">${name}</h2>
        <div class="card-info">
        <div class="rating">${stars}</div>
        <div class="price">От ${price} ₽</div>
        <div class="category">${kitchen}</div>
      </div>
    `;
  };

  const addToCart = (cartItem) => {
    const cartArray = getStoreValue('cart')
      ? JSON.parse(getStoreValue('cart'))
      : [];

    if (cartArray.some(item => item.id === cartItem.id)) {
        cartArray.map(item => {
          if (item.id === cartItem.id) {
            item.count++
          }
        });
    } else {
      cartArray.push(cartItem);
    }

    setStoreValue('cart', JSON.stringify(cartArray));
  };

  const renderItems = data => {
    data.forEach(({description, id, image, name, price}) => {
      const card = document.createElement('div');

      card.classList.add('card');
      card.innerHTML = `
        <img src="${image}" alt="${name}" class="card-image" />
        <div class="card-text">
          <div class="card-heading">
            <h3 class="card-title card-title-reg">${name}</h3>
          </div>
          <div class="card-info">
            <div class="ingredients">${description}</div>
          </div>
          <div class="card-buttons">
            <button class="button button-primary button-add-cart">
              <span class="button-card-text">В корзину</span>
              <span class="button-cart-svg"></span>
            </button>
            <strong class="card-price-bold">${price} ₽</strong>
          </div>
        </div>
      `;

      const add = card.querySelector('.button-card-text');
      add.addEventListener('click', () => {
        addToCart({
          id,
          name,
          price,
          count: 1
        });
      });

      cardsMenu.append(card);
    });
  };

  if (getStoreValue('auth')) {
    const restaurant = JSON.parse(getStoreValue('restaurant'));

    changeMenuHeader(restaurant);

    fetch(`https://delivery-service-76d92-default-rtdb.firebaseio.com/db/${restaurant.products}`)
      .then((response) => response.json())
      .then((data) => renderItems(data))
      .catch((error) => console.error(error));
  } else {
    window.location.href = '/delivery-service/index.html';
  }
}

export default menu;