const auth = () => {
  const buttonAuth = document.querySelector('.button-auth');
  const modalAuth = document.querySelector('.modal-auth');
  const buttonOut = document.querySelector('.button-out');
  const userName = document.querySelector('.user-name');
  const closeAuth = document.querySelector('.close-auth');
  const logInForm = document.getElementById('logInForm');
  const inputLogin = document.getElementById('login');
  const inputPassword = document.getElementById('password');
  const buttonCart = document.querySelector('.button-cart');

  // helpers
  const getFromStore = name => localStorage.getItem(name);
  const setFromStore = (name, value) => localStorage.setItem(name, value);
  const removeFromStore = name => localStorage.removeItem(name);

  const login = user => {
    buttonAuth.style.display = 'none';

    buttonOut.style.display = 'flex';
    userName.style.display = 'flex';
    buttonCart.style.display = 'flex';

    userName.textContent = user.login;
    modalAuth.style.display = 'none';
  };

  const logout = () => {
    buttonAuth.style.display = 'flex';

    buttonOut.style.display = 'none';
    userName.style.display = 'none';
    userName.textContent = '';
    buttonCart.style.display = 'none';

    removeFromStore('auth');
  }

  buttonAuth.addEventListener('click', () => {
    modalAuth.style.display = 'flex';
  });

  closeAuth.addEventListener('click', () => {
    modalAuth.style.display = 'none';
  });

  buttonOut.addEventListener('click', () => {
    logout();
  });

  logInForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const user = {
      login: inputLogin.value,
      password: inputPassword.value
    }

    setFromStore('auth', JSON.stringify(user));
    login(user);
  });

  if (getFromStore('auth')) {
    login(JSON.parse(getFromStore('auth')));
  }
}

export default auth;