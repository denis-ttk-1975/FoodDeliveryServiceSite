import auth from "./modules/auth";
import menu from "./modules/menu";
import cart from "./modules/cart";

auth();
menu();
cart();